# VPN Privacy and Security Setup

### Internship Task 8 - Cybersecurity Internship (Elevate Labs)

## Objective
To understand how VPNs protect online privacy and enable secure communication over public networks.

## Tools Used
- VPN Client: ProtonVPN (Free Tier)
- Browser: Google Chrome
- Verification Tool: https://whatismyipaddress.com

## Steps Performed
1. Selected ProtonVPN free tier.
2. Installed and logged in.
3. Connected to Japan server.
4. Verified IP change via whatismyipaddress.com.
5. Tested encrypted browsing.
6. Compared browsing speed with and without VPN.

## VPN Features
- AES-256-bit Encryption
- OpenVPN & IKEv2/IPSec Protocols
- Kill Switch & DNS Leak Protection
- No-Logs Policy

## Benefits
- Protects online identity and hides IP.
- Encrypts traffic on public Wi-Fi.
- Prevents ISP and tracker monitoring.
- Enables access to restricted content.

## Limitations
- Reduced browsing speed.
- Limited free server options.
- Some websites block VPN IPs.

## Deliverables
| File | Description |
| report/VPN_Report.pdf | Detailed internship report (with screenshots). |
| report/VPN_Report.docx | Editable report version. |
| screenshots/ | VPN usage screenshots. |
| vpn_setup_steps.txt | Step-by-step text summary. |
| vpn_summary.md | Task summary markdown. |
